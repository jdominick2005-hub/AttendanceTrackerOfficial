﻿using System;
using System.Windows.Forms;

namespace Student_Attendance_Monitoring_By_Group_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Sign_loginHere = new System.Windows.Forms.Label();
            this.txtlogin_showPass = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtlogin_registerHere = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtlogin_password = new System.Windows.Forms.TextBox();
            this.txtlogin_username = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // Sign_loginHere
            // 
            this.Sign_loginHere.AutoSize = true;
            this.Sign_loginHere.Location = new System.Drawing.Point(271, 339);
            this.Sign_loginHere.Name = "Sign_loginHere";
            this.Sign_loginHere.Size = new System.Drawing.Size(10, 13);
            this.Sign_loginHere.TabIndex = 28;
            this.Sign_loginHere.Text = " ";
            // 
            // txtlogin_showPass
            // 
            this.txtlogin_showPass.AutoSize = true;
            this.txtlogin_showPass.Location = new System.Drawing.Point(274, 263);
            this.txtlogin_showPass.Name = "txtlogin_showPass";
            this.txtlogin_showPass.Size = new System.Drawing.Size(102, 17);
            this.txtlogin_showPass.TabIndex = 25;
            this.txtlogin_showPass.Text = "Show Password";
            this.txtlogin_showPass.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(971, 100);
            this.panel3.TabIndex = 29;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtlogin_registerHere);
            this.panel4.Controls.Add(this.txtlogin_showPass);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.txtlogin_password);
            this.panel4.Controls.Add(this.txtlogin_username);
            this.panel4.Controls.Add(this.btn_login);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.Sign_loginHere);
            this.panel4.Location = new System.Drawing.Point(287, 178);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(430, 441);
            this.panel4.TabIndex = 30;
            // 
            // txtlogin_registerHere
            // 
            this.txtlogin_registerHere.AutoSize = true;
            this.txtlogin_registerHere.Location = new System.Drawing.Point(223, 388);
            this.txtlogin_registerHere.Name = "txtlogin_registerHere";
            this.txtlogin_registerHere.Size = new System.Drawing.Size(72, 13);
            this.txtlogin_registerHere.TabIndex = 35;
            this.txtlogin_registerHere.Text = "Register Here";
            this.txtlogin_registerHere.Click += new System.EventHandler(this.txtlogin_registerHere_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(84, 388);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 13);
            this.label13.TabIndex = 34;
            this.label13.Text = "Don\'t have an account?";
            // 
            // txtlogin_password
            // 
            this.txtlogin_password.Location = new System.Drawing.Point(68, 202);
            this.txtlogin_password.Multiline = true;
            this.txtlogin_password.Name = "txtlogin_password";
            this.txtlogin_password.Size = new System.Drawing.Size(307, 44);
            this.txtlogin_password.TabIndex = 33;
            // 
            // txtlogin_username
            // 
            this.txtlogin_username.Location = new System.Drawing.Point(68, 113);
            this.txtlogin_username.Multiline = true;
            this.txtlogin_username.Name = "txtlogin_username";
            this.txtlogin_username.Size = new System.Drawing.Size(309, 43);
            this.txtlogin_username.TabIndex = 32;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(177, 301);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(95, 35);
            this.btn_login.TabIndex = 31;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(67, 186);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 30;
            this.label11.Text = "Password";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(65, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 29;
            this.label9.Text = "Username";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(174, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "WELCOME";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(971, 749);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Name = "Form1";
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {


        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button usernamer;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button3;
        private Panel panel2;
        private TextBox login_password;
        private TextBox login_username;
        private Label label12;
        private Label label10;
        private PictureBox pictureBox2;
        private Label label6;
        private Button login_btn;
        private CheckBox login_showpass;
        private Label label7;
        private Label login_registerHere;
        private Label Sign_loginHere;
        private CheckBox txtlogin_showPass;
        private Panel panel3;
        private Panel panel4;
        private Label label8;
        private Button btn_login;
        private Label label11;
        private Label label9;
        private Label txtlogin_registerHere;
        private Label label13;
        private TextBox txtlogin_password;
        private TextBox txtlogin_username;
    }
}

